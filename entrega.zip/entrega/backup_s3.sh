#!/bin/bash

# Nombre real de tu bucket
BUCKET_NAME="backup-nokless-123"

# Carpeta que quieres respaldar
DIRECTORIO="/home/ec2-user/respaldo"

# Crear carpeta para guardar backups
mkdir -p /home/ec2-user/backups

# Archivo de backup con fecha y hora
BACKUP_FILE="/home/ec2-user/backups/backup_$(date +%F_%H-%M-%S).tar.gz"

# Archivo de log
LOG_FILE="backup.log"

echo "Iniciando respaldo: $(date)" >> $LOG_FILE

# Comprimir contenido de respaldo
tar -czf $BACKUP_FILE -C "$DIRECTORIO" . >> $LOG_FILE 2>&1

if [ $? -ne 0 ]; then
    echo "Error al comprimir el directorio" >> $LOG_FILE
    exit 1
fi

# Subir backup a S3
aws s3 cp $BACKUP_FILE s3://$BUCKET_NAME/ >> $LOG_FILE 2>&1

if [ $? -eq 0 ]; then
    echo "Backup subido correctamente: $(date)" >> $LOG_FILE
else
    echo "Error al subir a S3" >> $LOG_FILE
fi
